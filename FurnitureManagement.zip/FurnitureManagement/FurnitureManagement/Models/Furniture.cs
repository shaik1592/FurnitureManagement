﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FurnitureManagement.Models
{
    public class Furniture
    {
         public int FurnitureId { get; set; }

        [Display(Name = "Furniture Name")]
        [Column("varchar2(200)")]
        [Required]
        public string FurnitureName { get; set; }
        [Display(Name = "Furniture Category")]
        [Column("varchar2(250)")]
        public string FurnitureCategory { get; set; }
        [Column("float")]
        [Required]
        public float Price { get; set; }


    }
}
